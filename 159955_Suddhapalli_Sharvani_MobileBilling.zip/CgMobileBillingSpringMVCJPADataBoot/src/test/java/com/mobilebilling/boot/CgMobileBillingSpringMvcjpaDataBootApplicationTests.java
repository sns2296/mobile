package com.mobilebilling.boot;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.ArrayList;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.cg.mobilebilling.beans.Address;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.beans.PostpaidAccount;
import com.cg.mobilebilling.daoservices.CustomerDAOServices;
import com.cg.mobilebilling.daoservices.PlanDAOServices;
import com.cg.mobilebilling.daoservices.PostpaidDAOServices;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.services.BillingServices;
import com.cg.mobilebilling.springwebconfig.BillingConfig;

@RunWith(SpringRunner.class)
@SpringBootTest
public class CgMobileBillingSpringMvcjpaDataBootApplicationTests {
	@MockBean
	private  CustomerDAOServices customerDAO;
	@MockBean
	private PlanDAOServices planDAO;
	@MockBean
	private PostpaidDAOServices postpaidDAO;
	@Autowired
	private BillingServices billingServices;
	@Test
	public void acceptCustomerDetailsTest() throws CustomerDetailsNotFoundException, BillingServicesDownException {
		Customer customer = new Customer(111,"Neela", "Sharvani", "sharvani@gmail.com", "22/07/1996", new Address(505211, "pune", "Maharastra"));
		Mockito.when(customerDAO.save(customer)).thenReturn(customer);
		assertThat(billingServices.acceptCustomerDetails(customer)).isEqualTo(customer);	
	}
}
